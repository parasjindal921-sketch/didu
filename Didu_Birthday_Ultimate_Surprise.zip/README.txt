DIDU BIRTHDAY WEBSITE

Open index.html in a browser to preview.
To publish: upload the CONTENTS of this folder to Netlify Drop, or push the entire folder to GitHub and deploy with Vercel (Framework: Other).
Keep all photos and our-song.mp3 beside index.html.
Browsers require a click before playing music, so it starts when she opens her surprise.
